module.exports={
    uri:'mongodb+srv://fleapo:fleapo@appdev-ed3o5.mongodb.net/pallighting?retryWrites=true&w=majority',

}